package ${package}.service.impl;

import ${package}.service.HelloService;

public class HelloServiceImpl implements HelloService {

	public String getMessage() {
		return "Hello!";
	}

}