package org.seasar.cubby.convention;

public interface ForwardInfo {

	String getRewritePath();

	String getActionClassName();

	String getMethodName();

}
