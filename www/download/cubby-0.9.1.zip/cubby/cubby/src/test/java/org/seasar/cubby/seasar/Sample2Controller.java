package org.seasar.cubby.seasar;

import org.seasar.cubby.action.Action;

public class Sample2Controller extends Action {

}
