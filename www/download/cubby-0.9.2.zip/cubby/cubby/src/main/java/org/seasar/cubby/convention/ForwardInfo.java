package org.seasar.cubby.convention;

public interface ForwardInfo {

	String getForwardPath();

	String getActionClassName();

	String getMethodName();

}
