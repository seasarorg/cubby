package org.seasar.cubby.tomcat55.valves;

public class Constants {

    public static final String Package = "org.seasar.cubby.tomcat55.valves";

}
