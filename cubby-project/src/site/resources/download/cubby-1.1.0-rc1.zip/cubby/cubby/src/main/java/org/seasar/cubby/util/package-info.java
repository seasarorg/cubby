/**
 * 各種ユーティリティを提供します。
 * @since 1.0.0
 */
package org.seasar.cubby.util;
