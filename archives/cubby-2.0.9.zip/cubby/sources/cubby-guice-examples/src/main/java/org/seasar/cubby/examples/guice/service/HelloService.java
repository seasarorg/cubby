package org.seasar.cubby.examples.guice.service;

public interface HelloService {

	String getMessage();

}