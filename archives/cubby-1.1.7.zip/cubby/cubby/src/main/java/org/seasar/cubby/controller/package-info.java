/**
 * Cubbyフレームワークが使用するビューコントローラに関する機能を提供します。
 * @since 1.0.0
 */
package org.seasar.cubby.controller;
