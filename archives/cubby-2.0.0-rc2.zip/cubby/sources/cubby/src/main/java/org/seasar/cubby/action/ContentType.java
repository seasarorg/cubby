package org.seasar.cubby.action;

public @interface ContentType {
	String value() default "";
}
