package org.seasar.cubby.examples.spring.service;

public interface HelloService {

	String getMessage();

	
}