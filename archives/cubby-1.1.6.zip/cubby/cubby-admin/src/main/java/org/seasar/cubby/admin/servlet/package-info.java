/**
 * Cubbyの管理コンソールを提供します。
 * @since 1.1.0
 */
package org.seasar.cubby.admin.servlet;
