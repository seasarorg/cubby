package ${package}.service;

public interface HelloService {

	String getMessage();

}