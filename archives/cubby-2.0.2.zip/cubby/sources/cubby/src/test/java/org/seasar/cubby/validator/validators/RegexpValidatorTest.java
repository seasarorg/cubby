/*
 * Copyright 2004-2009 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.cubby.validator.validators;

import static org.seasar.cubby.validator.validators.ScalarFieldValidatorAssert.assertFail;
import static org.seasar.cubby.validator.validators.ScalarFieldValidatorAssert.assertSuccess;

import java.util.regex.Pattern;

import org.junit.Test;
import org.seasar.cubby.validator.ScalarFieldValidator;

public class RegexpValidatorTest {

	@Test
	public void validate1() {
		ScalarFieldValidator validator = new RegexpValidator("a.*34");
		assertSuccess(validator, null, "", "a5634");
		assertFail(validator, "b5634");
	}

	@Test
	public void validate2() {
		ScalarFieldValidator validator = new RegexpValidator(Pattern
				.compile("(?i)a.*34"));
		assertSuccess(validator, null, "", "a5634");
		assertSuccess(validator, null, "", "A5634");
		assertFail(validator, "b5634");
	}
}
