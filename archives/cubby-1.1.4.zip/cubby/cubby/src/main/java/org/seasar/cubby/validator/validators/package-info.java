/**
 * 定義済みの{@link org.seasar.cubby.validator.Validator 入力検証}を提供します。
 * @since 1.0.0
 */
package org.seasar.cubby.validator.validators;
