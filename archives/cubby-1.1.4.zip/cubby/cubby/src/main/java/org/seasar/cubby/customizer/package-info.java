/**
 * Sesaar2のコンポーネント定義をカスタマイズするコンポーネントカスタマイザのCubby向け実装クラスを提供します。
 * @since 1.0.0
 */
package org.seasar.cubby.customizer;
