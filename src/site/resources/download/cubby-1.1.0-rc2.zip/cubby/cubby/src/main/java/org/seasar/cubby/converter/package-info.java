/**
 * リクエストパラメータの型変換機能を提供します。
 * @since 1.1.0
 */
package org.seasar.cubby.converter;
