package org.seasar.cubby.validator;

/**
 * 入力検証を実行するフェーズを表します。
 * 
 * @author baba
 * @since 1.1.0
 */
public class ValidationPhase {
}
