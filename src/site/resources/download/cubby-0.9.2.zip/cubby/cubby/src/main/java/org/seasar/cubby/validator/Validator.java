package org.seasar.cubby.validator;

public interface Validator {

}
