// this file is dummy js file. 
// delete or replace this file.