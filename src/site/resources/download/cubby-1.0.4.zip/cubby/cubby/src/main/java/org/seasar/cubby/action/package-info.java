/**
 * アプリケーション開発者が使用するビューコントローラー部分を提供します。
 * @since 1.0.0
 */
package org.seasar.cubby.action;
